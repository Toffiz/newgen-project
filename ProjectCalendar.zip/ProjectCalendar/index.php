<!DOCTYPE html>

<html>

<head>

    <title>LOGIN</title>

    <link rel="stylesheet" type="text/css" href="login.css">

</head>

<body>
  <?php
  include 'connect.php';


  ?>
     <form action="index.php" method="post">

        <h2>LOGIN</h2>

        <label>User Name</label>

        <input id="email1" type="text" name="email" placeholder="User Name"><br>

        <label>Password</label>

        <input type="password" name="password" placeholder="Password"><br> 

        <button type="submit">Login</button>

     </form>

    <script>
      function clicked(){
                sessionStorage.setItem("user_email", document.getElementById("email1").value);
                var data = document.getElementById("target").textContent;
                sessionStorage.setItem("user_data", data);
        }

    </script>

<?php
    $email = filter_input(INPUT_POST, 'email');
    $password = filter_input(INPUT_POST, 'password');

    // Database connection
    $conn = new mysqli('localhost','root','','test');
      $data = "";

    if($conn->connect_error){
      echo "$conn->connect_error";
      die("Connection Failed : ". $conn->connect_error);
    } else {
          $sql = "SELECT fullname, roles, class FROM registration WHERE email='".$email."'";
          $result = $conn->query($sql);
          if($result->num_rows > 0){
              while($row = $result->fetch_assoc()) {
                  $data=$row['fullname']." ".$row['roles']." ".$row['class'];
              }
          }
  ?>

  <div id="target">
    <?php
    session_start();
              echo $data;
              $_SESSION["user_data"] = $data;
      }
    ?>
  </div>

</body>

<?php

    mysqli_close($conn);
        $conn = new mysqli('localhost','root','','test');


        if($conn->connect_error){
            echo "$conn->connect_error";
            die("Connection Failed : ". $conn->connect_error);
        } else {
        $sql = "SELECT email, passwords FROM registration";

        $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    if ($email == $row["email"]){
                        if($password == $row["passwords"]){
                            header("Location:main.php");
                            exit;
                        }
                        else{
                            break;
                        }
                    }
                    else{
                        
                    }
                }
            } else {
            }
    }
    mysqli_close($conn);
?>


</html>
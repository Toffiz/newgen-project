

function loading(){


    const data = sessionStorage.getItem("user_data");
    const user_class = data.split(" ")[12];

sessionStorage.setItem("user_class", user_class);
    if (user_role == "student"){
        const div = document.querySelector('.show_target');
    fetch('Classes.html')
    .then(res=>res.text())
    .then(data=>{
        div.innerHTML = data;   
        const parser = new DOMParser();
        const doc = parser.parseFromString(data, "text/html");
        eval(doc.querySelector('script').textContent);
    })
}
    else{
        const div = document.querySelector('.show_target');
    fetch('Teachers.html')
    .then(res=>res.text())
    .then(data=>{
        div.innerHTML = data;   
        const parser = new DOMParser();
        const doc = parser.parseFromString(data, "text/html");
        eval(doc.querySelector('script').textContent);
    })
    }
        
    
    

}

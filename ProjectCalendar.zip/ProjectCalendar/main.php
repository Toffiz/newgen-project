<!DOCTYPE html>

<html>

<head>

    <title>LOGIN</title>

    <link rel="stylesheet" type="text/css" href="main.css">

    <script src=
		"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js">
		</script>



</head>

<body onload="loading();"`>
        
    
    <div id="target">
        <?php
            session_start();
            echo $_SESSION["user_data"];
        ?>
    </div>
    
    <script>
                
        sessionStorage.setItem("user_data", document.getElementById("target").textContent);
        
    </script>
    <script src="user_data.js">
    </script>

    <div class="invisible" id="invisible_target"></div>

    <div class="show_target">
        
    </div>



    <script src="main1.js"></script>
</body>

</html>